# CCAPDEV
 This repository is For a web application project. This project is a reservation management system used to reserve slots from a computer labratory

Instructions:
1. Open terminal in and go to the same terminal
2. Type the code "npm init" to initialize the code
3. Type "npm i express express-handlebars body-parser mongodb" or "npm install" to install the nescessary modules
4. Type "node app.js" to run the server then go to localhost:3000

Sample Data
1. Sample data are located in the sampleData Folder
2. Run the app.js first to load the name of the collection
3. import each files based on names
4. refresh the page to show updated values

Samle data locations
1. All sample datas are located in the date 2024-03-12 of each lab
2. Each lab contains the reservation of a different user
3. 5 user and 5 labs were generated with 1 reservation per lab